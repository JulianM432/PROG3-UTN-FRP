package com.backend.testbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestbackendApplication.class, args);
	}

}
